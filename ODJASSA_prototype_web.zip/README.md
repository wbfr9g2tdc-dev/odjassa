# Ô’DJASSA — prototype web

## Contenu
- `index.html` : application web responsive en français.
- Recherche et filtres par catégories.
- Comparaison de prix par magasin.
- Panier local (sauvegarde dans le navigateur).
- Page magasins et formulaire de démonstration pour ajouter un produit.

## Limites importantes
Cette version est un prototype front-end. Les produits/prix/magasins sont fictifs ou illustratifs. Le panier et les modifications du catalogue restent dans le navigateur utilisé. Il n'y a pas de comptes, de base de données partagée, de commandes envoyées aux magasins, de paiement, de stock réel ou de suivi de livraison.

## Mise en ligne gratuite (site statique)
1. Décompressez le ZIP sur votre ordinateur.
2. Ouvrez https://app.netlify.com/drop dans un navigateur.
3. Déposez le dossier contenant `index.html` (ou glissez le dossier décompressé si Netlify l'accepte).
4. Netlify génère une URL publique. Conservez votre accès au compte pour gérer le site.

Alternative : https://vercel.com/ (importer un dépôt Git) ou https://pages.cloudflare.com/.

## Étape suivante pour un vrai service multi-utilisateur
Créer un projet sur https://supabase.com/ (base PostgreSQL + authentification), concevoir les tables `products`, `stores`, `store_prices`, `orders`, `profiles`, protéger l'administration avec des règles RLS, puis connecter le front-end à Supabase. Ne jamais mettre une clé secrète/service-role dans le code public. Il faudra également un compte admin sécurisé et des commerçants partenaires pour confirmer les prix et stocks.
